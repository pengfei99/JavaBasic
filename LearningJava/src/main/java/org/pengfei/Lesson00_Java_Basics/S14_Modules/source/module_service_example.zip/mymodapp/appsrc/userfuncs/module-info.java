// module definition for userfuncs module
//
module userfuncs {
// exports the package binaryfuncs of the module userfuncs
    exports userfuncs.binaryfuncs;
}
