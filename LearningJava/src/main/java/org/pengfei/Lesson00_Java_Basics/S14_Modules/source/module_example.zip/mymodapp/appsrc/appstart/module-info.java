module appstart{
// module def for the main appalication module, here we specify it depends on appfuncs module
requires appfuncs;
}
