module appfuncs{
//exports the package appfuncs.simplefuncs
exports appfuncs.simplefuncs;
}
