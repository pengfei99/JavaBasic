package appstart.mymodappdemo;

import appfuncs.simplefuncs.SimpleMathFuncs;

// add dependencies for service loader and userfuncs
import java.util.ServiceLoader;

import userfuncs.binaryfuncs.*;

public class MyModAppDemo {
    public static void main(String[] args) {

// old built-in functions
        if (SimpleMathFuncs.isFactor(2, 10)) System.out.println("2 is a factor of 10");
        int a = 35;
        int b = 105;

        System.out.println("Smallest common factor of " + a + " and " + b + " is " + SimpleMathFuncs.lcf(a, b));
        System.out.println("Largest common factor of " + a + " and " + b + " is " + SimpleMathFuncs.gcf(a, b));

// new service based, user defined operations
// Get a service loader for bianry functions
        ServiceLoader<BinFuncProvider> ldr = ServiceLoader.load(BinFuncProvider.class);

        BinaryFunc binOp = null;

// Find the provider for absPlus and obtain the function
        for (BinFuncProvider bfp : ldr) {
            if (bfp.get().getName().equals("absPlus")) {
                binOp = bfp.get();
                break;
            }
        }
        if (binOp != null) System.out.println("Result of absPlust function: " + binOp.func(12, -4));
        else System.out.println("absPlus function not found");

//Now, find the provider for absMinus 
        binOp = null;
        for (BinFuncProvider bfp : ldr) {
            if (bfp.get().getName().equals("absMinus")) {
                binOp = bfp.get();
                break;
            }
        }
        if (binOp != null) System.out.println("Result of absMinus function: " + binOp.func(12, -4));
        else System.out.println("absMinus function not found");


    }
}
