// module definition of module userfuncsimp
//
module userfuncsimp {
// this module depends on module userfuncs
    requires userfuncs;

// and it provides one service with two different implementations
    provides userfuncs.binaryfuncs.BinFuncProvider with userfuncsimp.binaryfuncsimp.AbsPlusProvider, userfuncsimp.binaryfuncsimp.AbsMinusProvider;
}
