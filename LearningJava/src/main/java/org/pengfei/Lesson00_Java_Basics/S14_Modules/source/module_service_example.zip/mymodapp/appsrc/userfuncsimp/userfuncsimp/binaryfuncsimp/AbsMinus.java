package userfuncsimp.binaryfuncsimp;

import userfuncs.binaryfuncs.BinaryFunc;

public class AbsMinus implements BinaryFunc {

    // return the name of this function
    public String getName() {
        return "absMinus";
    }

    // Implement the AbsPlus function
    public int func(int a, int b) {
        return Math.abs(a) - Math.abs(b);
    }
}
