module appstart {
// module def for the main appalication module, here we specify it depends on appfuncs module
    requires appfuncs;

// appstart module depends userfuncs module
    requires userfuncs;

// appstart uses BinFuncProvider
    uses userfuncs.binaryfuncs.BinFuncProvider;
}
